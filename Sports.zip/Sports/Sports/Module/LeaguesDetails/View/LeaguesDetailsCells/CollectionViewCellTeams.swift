//
//  CollectionViewCellTeams.swift
//  Sports
//
//  Created by Rawan Bahnasy on 5/13/22.
//  Copyright © 2022 ayahassan. All rights reserved.
//

import UIKit

class CollectionViewCellTeams: UICollectionViewCell {

    @IBOutlet weak var teamsImg: UIImageView!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
