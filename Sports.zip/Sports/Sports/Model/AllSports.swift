//
//  AllSports.swift
//  Sports
//
//  Created by ayahassan on 5/13/22.
//  Copyright © 2022 ayahassan. All rights reserved.
//

import Foundation

struct AllSports :Decodable{
     var sports : [Sport]?
}
