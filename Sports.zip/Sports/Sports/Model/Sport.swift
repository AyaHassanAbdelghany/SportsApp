//
//  Sport.swift
//  Sports
//
//  Created by ayahassan on 5/13/22.
//  Copyright © 2022 ayahassan. All rights reserved.
//

import Foundation

struct Sport :Decodable{
    
   var idSport  : String?
   var strSport : String?
   var strSportThumb  : String?
    var strSportIconGreen : String?
    var strFormat  : String?
    var strSportDescription  : String?

}
